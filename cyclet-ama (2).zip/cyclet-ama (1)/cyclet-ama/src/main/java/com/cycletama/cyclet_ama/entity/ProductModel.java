package com.cycletama.cyclet_ama.entity;


import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
public class ProductModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String model;
    private String productCode;
     private BigDecimal pricePerCarton;
     private Integer stock;
     private Integer piecesPerCarton;
     private String status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public BigDecimal getPricePerCarton() {
        return pricePerCarton;
    }

    public void setPricePerCarton(BigDecimal pricePerCarton) {
        this.pricePerCarton = pricePerCarton;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Integer getPiecesPerCarton() {
        return piecesPerCarton;
    }

    public void setPiecesPerCarton(Integer piecesPerCarton) {
        this.piecesPerCarton = piecesPerCarton;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    @ManyToOne
    private Product product;

}
