package com.cycletama.cyclet_ama.controller;


import com.cycletama.cyclet_ama.dto.ProductDTO;
import com.cycletama.cyclet_ama.entity.Product;
import com.cycletama.cyclet_ama.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService productService;
    public ProductController(ProductService productService) {
        this.productService = productService;
    }
    @GetMapping
    public List<ProductDTO> GetAllProducts() {
        return productService.GetAllProducts();
    }
    @PostMapping
    public ProductDTO createProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    @GetMapping("/{id}")
    public ProductDTO getProductById(@PathVariable Long id) {
        return productService.getProductById(id);
    }

    @PutMapping("/{id}")
    public Product updateProduct(@PathVariable Long id, @RequestBody Product product) {
        return productService.updateProduct(id, product);
    }

    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
    }

    @PostMapping("/{productId}/categories/{categoryId}")
    public void addCategoryToProduct(@PathVariable Long productId, @PathVariable Long categoryId) {
        productService.addCategoryToProduct(productId, categoryId);
    }

    @DeleteMapping("/{productId}/categories/{categoryId}")
    public void removeCategoryFromProduct(@PathVariable Long productId, @PathVariable Long categoryId) {
        productService.removeCategoryFromProduct(productId, categoryId);
    }
}
